PLUGIN.name = "Old cloth"
PLUGIN.author = "Prai'ns\Droda\LiGyH"
PLUGIN.desc = "Плагин для упрощения айтемов одежды."