ITEM.name = "Берилл"
ITEM.desc = "Берилл"
ITEM.model = Model("models/stalkertnb/sunrise_berill.mdl")
ITEM.category = "Броня"
ITEM.price = 5560
ITEM.flag = "O"