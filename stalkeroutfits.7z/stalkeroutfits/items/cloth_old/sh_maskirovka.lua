ITEM.name = "Маскировочный Халат"
ITEM.desc = "Маскировочный Халат"
ITEM.model = Model("models/stalkertnb/sunrise_mccrae2.mdl")
ITEM.category = "Броня"
ITEM.price = 5700
ITEM.flag = "O"