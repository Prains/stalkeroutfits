ITEM.name = "Бронекостюм Наемников"
ITEM.desc = "Бронекостюм Наемников"
ITEM.model = Model("models/ninja/stalker_mercenary_00.mdl")
ITEM.category = "Броня"
ITEM.price = 2500