ITEM.name = "Улучшенная СЕВА"
ITEM.desc = "Улучшенная СЕВА"
ITEM.model = Model("models/stalkertnb/seva_heavy.mdl")
ITEM.category = "Броня"
ITEM.price = 10000
ITEM.flag = "O"